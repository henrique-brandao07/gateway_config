
MAC=$(get_uvar ethaddr | tr -d ':')
(
# Update U-Boot
prod_flash_script     ./tmp/script_uboot.img
prod_flash_kernel     ./tmp/uImage
prod_flash_initramfs  ./tmp/initramfs.cpio.gz.uboot

# TO enable if clean rescue is wanted
#prod_flash_rootfs     ./tmp/rootfs.tar.gz

#
# Update rescue FS
#
[ -d ${MOUNT_POINT_RESCUEFS} ] || mkdir -p ${MOUNT_POINT_RESCUEFS}
mount -t yaffs2 ${RESCUEFS_PART} ${MOUNT_POINT_RESCUEFS}

PWD_BACKUP=${PWD}
cd /tmp
tar -xf ${dota} rootfs.tar.gz
[ $? -eq 0 ] && mv rootfs.tar.gz ${MOUNT_POINT_RESCUEFS}/${FS_RESCUE}
ret=$?
cd ${PWD_BACKUP}

if [ $ret -ne 0 ]
then
	error "Failed to create rootfs backup, partial upgrade detected. Rootfs restore lost."
	rm -f ${MOUNT_POINT_RESCUEFS}/${FS_RESCUE}
	umount ${MOUNT_POINT_RESCUEFS}
	return 1
fi

# Update prod firmware version
fw_setenv prod_fw "wirmaV2_wirnet_v3.6"

# Retrieve klk-version file
cat /tmp/klk_update >> etc/klk_update

# Reset bootfail counter
fw_setenv bootfail 0

#
# Retrieve custos and prepare them for next reboot
#
echo "Retrieve custos and prepare them for next reboot"
ls ./mnt/fsuser-1/dota/
mkdir -p ./mnt/fsuser-1/dota/
cp ${MOUNT_POINT_RESCUEFS}/custo* ./mnt/fsuser-1/dota/
echo "Prepare USERFS or APPLICATION update for next reboot"
[ -f ./tmp/dota_userfs.tar ] && mv ./tmp/dota_userfs.tar ./mnt/fsuser-1/dota/
[ -f ./tmp/dota_app.tar ] && mv ./tmp/dota_app.tar ./mnt/fsuser-1/dota/

sync
) > /tmp/update2.log 2>&1

cat /tmp/update2.log

cat /tmp/update1.log /tmp/update2.log >> ./mnt/mmcblk0p1/fwupgrade_wirmaV2_wirnet_v3.6_${MAC:=00}.log
cat /tmp/update1.log /tmp/update2.log >> ./var/log/fwupgrade_wirmaV2_wirnet_v3.6_${MAC:=00}.log

