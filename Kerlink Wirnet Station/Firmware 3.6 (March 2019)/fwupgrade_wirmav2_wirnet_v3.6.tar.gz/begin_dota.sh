#!/bin/sh

get_file_size() {
	size=$(ls -l $1 | awk '{print $5}')
	echo ${size}
}

dota_error=0

MAC=$(get_uvar ethaddr | tr -d ':')
(
echo "*********************************"
echo "********** STEP  1 **************"
echo "*********************************"
date
echo "------------------ kernel log dump ----------------"
dmesg
echo "---------------------------------------------------"

echo "executing ${dota}"

#
# Backup klk-update
#
cp etc/klk_update /tmp/

#
# Mount rescue fs
#
[ -d ${MOUNT_POINT_RESCUEFS} ] || mkdir -p ${MOUNT_POINT_RESCUEFS}
mount -t yaffs2 ${RESCUEFS_PART} ${MOUNT_POINT_RESCUEFS}
if [ $? -ne 0 ]
then
	error "Failed to mount rescuefs partition (${RESCUEFS_PART}). Do not upgrade."
	dota_error=1
fi

#
# backup config
#
if [ ! -z " etc/sysconfig/network etc/shadow knet/knetd.xml" -a ${dota_error} -eq 0 ]; then
	echo "Creating custo_backup_v3.tar.gz:  etc/sysconfig/network etc/shadow knet/knetd.xml"
	real_list=$(ls  etc/sysconfig/network etc/shadow knet/knetd.xml)
	echo "real_list = \"${real_list}\""
	if true
	then
		echo "rm -f etc/rc.d/rc3.d/S*change-password" > post_dota.sh
		real_list="${real_list} post_dota.sh"
	fi
	if [ ! -z "${real_list}" ]; then
		echo "tar -cvzf custo_backup_v3.tar.gz"
		tar -cvzf ${MOUNT_POINT_RESCUEFS}/custo_backup_v3.tar.gz ${real_list}
		if [ $? -ne 0 ]
		then
			error "Failed to create custo_backup_v3.tar.gz. Do not upgrade."
			rm -f ${MOUNT_POINT_RESCUEFS}/custo_backup_v3.tar.gz
			dota_error=1
		fi
	fi
	rm -f post_dota.sh
else
	echo "No custo_backup_v3.tar.gz, no backup list"
fi

if [ ${dota_error} -eq 0 ]; then
	#
	# check size of backup config and v3 rootfs
	#
	if [ -f ${MOUNT_POINT_RESCUEFS}/custo_backup_v3.tar.gz ]; then
		custo_size=$(get_file_size "${MOUNT_POINT_RESCUEFS}/custo_backup_v3.tar.gz")
	else
		custo_size="0"
	fi
	rootfs_v3_size=9492161
	if [ -f ${MOUNT_POINT_RESCUEFS}/fs_rescue.tar.gz ]; then
		rootfs_current_size=$(get_file_size "${MOUNT_POINT_RESCUEFS}/fs_rescue.tar.gz")
	else
		rootfs_current_size="0"
	fi
	rescue_part_free_space=$(df ${RESCUEFS_PART} | grep ${RESCUEFS_PART} | awk '{print $4}')
	rescue_part_free_space=$((${rescue_part_free_space} * 1024))
	needed_free_space=$((${custo_size} + ${rootfs_v3_size} - ${rootfs_current_size} + 10240))
	if [ "${needed_free_space}" -gt "${rescue_part_free_space}" ]; then
		info "custo_size: ${custo_size}"
		info "rootfs_v3_size: ${rootfs_v3_size}"
		info "rootfs_current_size: ${rootfs_current_size}"
		info "rescue_part_free_space: ${rescue_part_free_space}"
		error "Not enough space in rescue partition for upgrade. Do not upgrade."
		dota_error=1
	fi
fi

if [ ${dota_error} -eq 1 ]; then
	# Remove dota
	rm -f ${dota}
	# Remove saved custo
	rm -f ${MOUNT_POINT_RESCUEFS}/custo_backup_v3.tar.gz
	sync
	umount ${MOUNT_POINT_RESCUEFS} > /dev/null 2>&1
	error "Upgrade cancelled."
	exit_initramfs
fi

sync
umount ${MOUNT_POINT_RESCUEFS}

) > /tmp/update1.log 2>&1

cat /tmp/update1.log

